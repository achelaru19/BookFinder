#config file containing credentials for RDS MySQL instance
db_username = "achelaru"
db_password = "Cosimini28Marruota"
db_name = "bookfinder" 

